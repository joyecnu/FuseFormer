import numpy as np
import torch
from torch import nn
import torch.nn.functional as F

# Whether use adjoint method or not.
adjoint = False
if adjoint:
    from torchdiffeq import odeint_adjoint as odeint
else:
    from torchdiffeq import odeint
from core.manifolds import Oblique
from model.multipath.transformerlib import MultiheadAttention

import torch
from torch import nn, Tensor
import copy
from torch.nn import functional as F
from torch.nn.modules.module import Module
from torch.nn.modules.container import ModuleList
from typing import Optional  # need to pay attention
# from multipathtransformer import  TransformerDecoderLayer
from torch.nn.modules.dropout import Dropout
from torch.nn.modules.linear import Linear, _LinearWithBias
from torch.nn.modules.normalization import LayerNorm
# Define the ODE function.
# Input:
# --- t: A tensor with shape [], meaning the current time.
# --- x: A tensor with shape [#batches, dims], meaning the value of x at t.
# Output:
# --- dx/dt: A tensor with shape [#batches, dims], meaning the derivative of x at t.
# class ODEFunc(nn.Module):
#
#     def __init__(self, feature_dim, temporal_dim, adj):
#         super(ODEFunc, self).__init__()
#         self.adj = adj
#         self.x0 = None
#         self.alpha = nn.Parameter(0.8 * torch.ones(adj.shape[1]))
#         self.beta = 0.6
#         self.w = nn.Parameter(torch.eye(feature_dim))
#         self.d = nn.Parameter(torch.zeros(feature_dim) + 1)
#         self.w2 = nn.Parameter(torch.eye(temporal_dim))
#         self.d2 = nn.Parameter(torch.zeros(temporal_dim) + 1)
#
#     def forward(self, t, x):
#         alpha = torch.sigmoid(self.alpha).unsqueeze(-1).unsqueeze(-1).unsqueeze(0)
#         xa = torch.einsum('ij, kjlm->kilm', self.adj, x)
#
#         # ensure the eigenvalues to be less than 1
#         d = torch.clamp(self.d, min=0, max=1)
#         w = torch.mm(self.w * d, torch.t(self.w))
#         xw = torch.einsum('ijkl, lm->ijkm', x, w)
#
#         d2 = torch.clamp(self.d2, min=0, max=1)
#         w2 = torch.mm(self.w2 * d2, torch.t(self.w2))
#         xw2 = torch.einsum('ijkl, km->ijml', x, w2)
#
#         f = alpha / 2 * xa - x + xw - x + xw2 - x + self.x0
#         return f

# class ODEFunc(nn.Module):
#     def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
#         super().__init__()
#         self.num_heads = num_heads
#         head_dim = dim // num_heads
#         # NOTE scale factor was wrong in my original version, can set manually to be compat with prev weights
#         self.scale = qk_scale or head_dim ** -0.5
#
#         self.qkv = nn.Linear(dim, dim, bias=qkv_bias)
#         self.attn_drop = nn.Dropout(attn_drop)
#         self.proj = nn.Linear(dim, dim)
#         self.proj_drop = nn.Dropout(proj_drop)
#
#     def forward(self, t,x):
#         v = self.qkv(x)
#         M = Oblique()
#         xM = M.proj(x)
#         attn = (M.dist(xM, xM).neg())
#         attn = attn.softmax(dim=-1)
#         attn = self.attn_drop(attn)
#
#         x = attn @ v
#         x = self.proj(x)
#         x = self.proj_drop(x)
#         return   x

# class ODEFunc(nn.Module):
#     def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
#         super().__init__()
#         self.num_heads = num_heads
#         head_dim = dim // num_heads
#         self.model_dim = dim
#         # NOTE scale factor was wrong in my original version, can set manually to be compat with prev weights
#         self.scale = qk_scale or head_dim ** -0.5
#
#         self.qkv = nn.Linear(dim, dim, bias=qkv_bias)
#         self.attn_drop = nn.Dropout(attn_drop)
#         self.proj = nn.Linear(dim, dim)
#         self.proj_drop = nn.Dropout(proj_drop)
#         self.temporal_attention_before = MultiheadAttention(dim, num_heads, dropout=attn_drop)
#
#         self.temporal_info = nn.Linear(dim, dim)
#         self.temporal_gate = nn.Linear(dim, dim)
#     def gsa(self,x):
#         v = self.qkv(x)
#         M = Oblique()
#         xM = M.proj(x)
#         attn = (M.dist(xM, xM).neg())
#         attn = attn.softmax(dim=-1)
#         attn = self.attn_drop(attn)
#
#         x = attn @ v
#         x = self.proj(x)
#         x = self.proj_drop(x)
#         return x
#     def gate(self,attn):
#         t_in = attn
#         t_info = torch.tanh(self.temporal_info(t_in))
#         t_gate = torch.sigmoid(self.temporal_gate(t_in))
#         t_attn = t_info * t_gate
#         return t_attn
#     def forward(self, t,x):
#         query=x
#         key = x
#         value = x
#         num_agent = query.shape[1]
#         sample_num = query.shape[2]
#         query_len = query.shape[0]  # T - query
#         key_len = key.shape[0]  # T - key and value
#         t_query = query.reshape([query_len, num_agent * sample_num, self.model_dim])
#         t_key = key.reshape([key_len, num_agent * sample_num, self.model_dim])
#         t_value = value.reshape([key_len, num_agent * sample_num, self.model_dim])
#
#         attn_multi, _ = self.temporal_attention_before(t_query,t_key,t_value)
#
#         attn_gas = self.gsa(t_query)
#
#         x = self.gate(attn_gas)+self.gate(attn_multi)
#         x = x.reshape([query_len, num_agent, sample_num, self.model_dim])
#
#         return  x

class TransformerDecoder_ode(nn.Module):
    r"""TransformerDecoder is a stack of N decoder layers

    Args:
        decoder_layer: an instance of the TransformerDecoderLayer() class (required).
        num_layers: the number of sub-decoder-layers in the decoder (required).
        norm: the layer normalization component (optional).

    Examples::
        >>> decoder_layer = nn.TransformerDecoderLayer(d_model=512, nhead=8)
        >>> transformer_decoder = nn.TransformerDecoder(decoder_layer, num_layers=6)
        >>> memory = torch.rand(10, 32, 512)
        >>> tgt = torch.rand(20, 32, 512)
        >>> out = transformer_decoder(tgt, memory)
    """
    __constants__ = ['norm']

    def __init__(self, decoder_layer, num_layers, norm=None):
        super().__init__()
        self.layers = _get_clones(decoder_layer, num_layers)
        self.num_layers = num_layers
        self.norm = norm

    def forward(self, tgt: Tensor, memory: Tensor, tgt_mask: Optional[Tensor] = None,
                memory_mask: Optional[Tensor] = None, seq_mask=False, tgt_key_padding_mask: Optional[Tensor] = None,
                memory_key_padding_mask: Optional[Tensor] = None, need_weights=False, num_agent=1) -> Tensor:
        r"""Pass the inputs (and mask) through the decoder layer in turn.

        Args:
            tgt: the sequence to the decoder (required).
            memory: the sequence from the last layer of the encoder (required).
            tgt_mask: the mask for the tgt sequence (optional).
            memory_mask: the mask for the memory sequence (optional).
            tgt_key_padding_mask: the mask for the tgt keys per batch (optional).
            memory_key_padding_mask: the mask for the memory keys per batch (optional).

        Shape:
            see the docs in Transformer class.
        """
        output = tgt

        self_attn_weights = [None] * len(self.layers)
        cross_attn_weights = [None] * len(self.layers)
        for i, mod in enumerate(self.layers):
            output, self_attn_weights[i], cross_attn_weights[i] = mod(output, memory, tgt_mask=tgt_mask,
                                                                      memory_mask=memory_mask, seq_mask=seq_mask,
                                                                      tgt_key_padding_mask=tgt_key_padding_mask,
                                                                      memory_key_padding_mask=memory_key_padding_mask,
                                                                      need_weights=need_weights)

        if self.norm is not None:
            output = self.norm(output)

        if need_weights:  # need to modify, do not stack
            self_attn_weights = torch.stack(self_attn_weights).cpu().numpy()
            cross_attn_weights = torch.stack(cross_attn_weights).cpu().numpy()

        return output, {'self_attn_weights': self_attn_weights, 'cross_attn_weights': cross_attn_weights}

class ODEblock(nn.Module):
    def __init__(self, odefunc, t=torch.tensor([0,1])):
        super(ODEblock, self).__init__()
        self.t = t
        self.odefunc = odefunc

    def set_x0(self, tgt, memory):

        self.odefunc.tgt = tgt.clone().detach()
        self.odefunc.tgt = memory.clone().detach()


    def forward(self, x):
        t = self.t.type_as(x)
        z = odeint(self.odefunc, x, t, method='euler')[1]
        return z


# Define the ODEGCN model.
class ODEG(nn.Module):
    def __init__(self, decoder_layers, nlayer,  time):#decoder_layers transformer 层   nlayer transformer层数
        super(ODEG, self).__init__()
        # self.odeblock = ODEblock(ODEFunc(feature_dim, temporal_dim), t=torch.tensor([0, time]))#TransformerDecoder_ode

        self.odeblock = ODEblock(TransformerDecoder_ode(decoder_layers, nlayer), t=torch.tensor([0, time]))


    def forward(self, tgt: Tensor, memory: Tensor, tgt_mask: Optional[Tensor] = None,
                memory_mask: Optional[Tensor] = None, seq_mask=False, tgt_key_padding_mask: Optional[Tensor] = None,
                memory_key_padding_mask: Optional[Tensor] = None, need_weights=False, num_agent=1):
        self.odeblock.set_x0(tgt, memory)
        z = self.odeblock(tgt, memory,tgt_mask=tgt_mask,memory_mask = memory_mask,
                    seq_mask=seq_mask, tgt_key_padding_mask = tgt_key_padding_mask,
                    memory_key_padding_mask= memory_key_padding_mask,
                    need_weights=need_weights, num_agent=num_agent)
        return F.relu(z)


def _get_clones(module, N):
    return ModuleList([copy.deepcopy(module) for i in range(N)])


def _get_activation_fn(activation):
    if activation == "relu":
        return F.relu
    elif activation == "gelu":
        return F.gelu

    raise RuntimeError("activation should be relu/gelu, not {}".format(activation))